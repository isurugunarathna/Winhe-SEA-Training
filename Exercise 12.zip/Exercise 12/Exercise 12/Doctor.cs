﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_12
{
    public class Doctor
    {
        private string fullName;
        private string registryNumber;
        private string speciality;

        public Doctor(string fullName, string registryNumber,string speciality)
        {
            this.fullName = fullName;
            this.registryNumber = registryNumber;
            this.speciality = speciality;
        }
        public string getFullName()
        {
            return fullName;
        }
        public string getRegistryNumber()
        {
            return registryNumber;
        }
        public string getSpeciality()
        {
            return speciality;
        }
        public void SetName(string fullName)
        {
            this.fullName = fullName;
        }
        public bool Equals(Doctor doctor)
        {
            if (this.registryNumber == doctor.registryNumber)
            {
                return true;
            }

            return false;
        }
        public string ToString()
        {
            return "Dr. " + fullName + ", Specialty : " + speciality;
        }
    }
}
