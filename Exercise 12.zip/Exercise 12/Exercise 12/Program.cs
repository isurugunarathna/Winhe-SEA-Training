﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DoctorRegistry dr = new DoctorRegistry("Colombo");
            Doctor d = new Doctor("Isuru", "4545", "Heart");
            dr.register(d);
            if (!dr.register(d))
            {
                Console.WriteLine("Already on list");
            }
            Console.ReadKey();
        }
    }
}
