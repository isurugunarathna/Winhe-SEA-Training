﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Exercise_12
{
    public class DoctorRegistry
    {
        private string province;
        private ArrayList doctors = new ArrayList();

        public DoctorRegistry(string province)
        {
            this.province = province;
        }

        public bool register(Doctor doctor)
        {
            for (int i = 0; i < doctors.Count; i++)
            {
                if (doctors[i] == doctor)
                {
                    return false;
                }
            }
            doctors.Add(doctor);
            return true;
        }

        public bool deRegister(string registernumber)
        {
            for (int i = 0; i < doctors.Count; i++)
            {
                if (((Doctor)doctors[i]).getRegistryNumber() == registernumber)
                {
                    doctors.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public ArrayList getDoctorList()
        {
            return doctors;
        }
    }
}
