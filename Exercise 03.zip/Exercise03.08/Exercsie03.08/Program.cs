﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercsie03._08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double sum = 0, average = 0;
            
            double[] numbers = new double[10];
            for (int i = 0; i < 10; i++)
            {
                Console.Write("Number {0}: ", i + 1);
                numbers[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + numbers[i];
            }
            average = sum / numbers.Length;
            Console.WriteLine("The Sum is : " + sum);
            Console.WriteLine("The Average is : " + average);

            Console.ReadKey();

        }
    }
}
