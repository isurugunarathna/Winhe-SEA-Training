﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise03._12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = { 1, 5, 9, 8, 7,0 };
            int[] array2 = { 6, 5, 9, 1, 0, 2, 5 };

            
            var intersect = array1.Intersect(array2);

            Console.WriteLine("Similar Elements in Two Arrays");

            foreach (int value in intersect)
            {
                Console.WriteLine(value);
            }
            Console.ReadKey();
        }
    }
}
