﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise03._04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, sum = 0;

            // Reading number
            Console.WriteLine("Enter any number : ");
            int number = Convert.ToInt32(Console.ReadLine());

            for (i = 2; i <= number; i += 2)
            {
                
                sum = sum + i;
            }
            Console.WriteLine("Sum of all even number between 1 to " + number + " = " + sum);

            Console.ReadKey();
        }
    }
}
