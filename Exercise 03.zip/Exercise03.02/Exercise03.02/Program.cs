﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise03._02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int j, sum = 0;

            Console.WriteLine("Find the sum of first 10 natural numbers :");
            Console.WriteLine("----------------------------------------------");

            Console.WriteLine("The first 10 natural number are :\n");
            for (j = 1; j <= 10; j++)
            {
                sum = sum + j;
                Console.Write("{0} ", j);
            }
            Console.WriteLine("");
            Console.WriteLine("");

            Console.WriteLine("The Sum is : " + sum);

            Console.ReadKey();
        }
    }
}
