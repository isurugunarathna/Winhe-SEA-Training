﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise08._02
{
    internal class Animal
    {
        protected String name;

        public Animal(string name)
        {
            this.name = name;
        }

        public virtual string toString()
        {
            return "Animal: Animal[name =" + name + "]";

        }
    }
}
