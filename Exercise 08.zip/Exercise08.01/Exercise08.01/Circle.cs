﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise08._01
{
    internal class Circle : Shape
    {
        private double radius = 1.0;

        public Circle() : base()
        {

        }

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public Circle(double radius, String color, bool filled) : base(color, filled)
        {
            this.radius = radius;
        }

        public double getRadius()
        {
            return radius;
        }

        public void setRadius(double radius)
        {
            this.radius = radius;
        }

        public double getArea()
        {
            return 3.14 * radius * radius;
        }

        public double getParimeter()
        {
            return 2 * 3.14 * radius;
        }

        public string toString()
        {
            return "Circle [" + base.toString() + "," + "radius = " + radius + "]";
        }
    }
}
