﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise06._01
{
    internal class Program
    {

        static void averageMArks()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int total = 0;
            double average = 0;
            for (int i = 0; i < studentMarks.GetLength(1); i++)
            {
                total = 0;
                average = 0;
                for (int j = 0; j < studentMarks.GetLength(0); j++)
                {

                    total += studentMarks[j, i];
                }
                average = (double)total / studentMarks.GetLength(0);
                Console.WriteLine("Subject " + (i + 1) + " has an average of " + average);
            }
        }
        static void averageSubject()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int total = 0;
            double average = 0;
            for (int i = 0; i < studentMarks.GetLength(0); i++)
            {
                total = 0;
                average = 0;
                for (int j = 0; j < studentMarks.GetLength(1); j++)
                {

                    total += studentMarks[i, j];
                }
                average = (double)total / studentMarks.GetLength(1);
                Console.WriteLine("Student " + (i + 1) + " has an average of " + average);

            }

        }
        static void maximumSubject()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int max = int.MinValue;
            for (int i = 0; i < studentMarks.GetLength(1); i++)
            {
                max = int.MinValue;
                for (int j = 0; j < studentMarks.GetLength(0); j++)
                {
                    if (studentMarks[j, i] > max)
                    {
                        max = studentMarks[j, i];
                    }
                }
                Console.WriteLine("For Subject " + (i + 1) + " the maximum number is " + max);
            }
        }
        static void minimumSubject()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int min = int.MaxValue;
            for (int i = 0; i < studentMarks.GetLength(1); i++)
            {
                min = int.MaxValue;
                for (int j = 0; j < studentMarks.GetLength(0); j++)
                {
                    if (studentMarks[j, i] < min)
                    {
                        min = studentMarks[j, i];
                    }
                }
                Console.WriteLine("For Subject " + (i + 1) + " the minimum mark is " + min);
            }

        }
        static void maximumStudent()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int max = int.MinValue;
            for (int i = 0; i < studentMarks.GetLength(0); i++)
            {
                max = int.MinValue;
                for (int j = 0; j < studentMarks.GetLength(1); j++)
                {
                    if (studentMarks[i, j] > max)
                    {
                        max = studentMarks[i, j];
                    }
                }

                Console.WriteLine("For Student " + (i + 1) + " the maximum mark is " + max);

            }
        }
        static void minimumStudent()
        {
            int[,] studentMarks = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };

            int min = int.MaxValue;
            for (int i = 0; i < studentMarks.GetLength(0); i++)
            {
                min = int.MaxValue;
                for (int j = 0; j < studentMarks.GetLength(1); j++)
                {
                    if (studentMarks[i, j] < min)
                    {
                        min = studentMarks[i, j];
                    }
                }

                Console.WriteLine("For Student " + (i + 1) + " the minimum mark is " + min);
            }
        }
        public static void Main()
        {
            Console.WriteLine("Average Marks ");
            averageMArks();

            Console.WriteLine("");
            Console.WriteLine("Average Subjects ");
            averageSubject();

            Console.WriteLine("");
            Console.WriteLine("Maximum Subject");
            maximumSubject();

            Console.WriteLine("");
            Console.WriteLine("Minimum Subject");
            minimumSubject();

            Console.WriteLine("");
            Console.WriteLine("Maximum Student");
            maximumStudent();

            Console.WriteLine("");
            Console.WriteLine("Minimum Student");
            minimumStudent();

            Console.ReadKey();
        }
        
        
    }
}
