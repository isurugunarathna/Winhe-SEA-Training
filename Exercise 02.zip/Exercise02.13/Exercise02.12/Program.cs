﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Radius of the base :");
            int radius = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the height of the cylinder :");
            int height = Convert.ToInt32(Console.ReadLine());

            double surfaceArea = ((2 * 3.14 * radius) * height );

            double volume = (3.14 * (radius * radius) * height);

            Console.WriteLine("Surface Area of the Cylinder : " + surfaceArea);
            Console.WriteLine("Volume of the Cylinder : " + volume);

            Console.ReadKey();
        }
    }
}
