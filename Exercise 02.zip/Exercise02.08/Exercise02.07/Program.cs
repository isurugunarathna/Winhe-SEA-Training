﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Student Number");
            int number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Student Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Module 1 Marks");
            int moduleOne = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Module 2 Marks");
            int moduleTwo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Module 3 Marks");
            int moduleThree = Convert.ToInt32(Console.ReadLine());

            int totalMarks = (moduleOne + moduleTwo + moduleThree);

            int averageMarks = (totalMarks/3);

            Console.WriteLine("");
            Console.WriteLine("==============");
            //Printing Student Results
            Console.WriteLine("Student Number : " + number);
            Console.WriteLine("Student Name : " + name);
            Console.WriteLine("Total Marks : " + totalMarks);
            Console.WriteLine("Average Marks : " + averageMarks);

            if(averageMarks > 50)
            {
                Console.WriteLine("Pass");
            }
            else
            {
                Console.WriteLine("Fail");
            }

            Console.ReadLine();
        }
    }
}
