﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Student Number");
            int number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Student Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Module 1 Marks");
            int moduleOne = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Module 2 Marks");
            int moduleTwo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Module 3 Marks");
            int moduleThree = Convert.ToInt32(Console.ReadLine());

            int totalMarks = (moduleOne + moduleTwo + moduleThree);

            int averageMarks = (totalMarks / 3);

            Console.WriteLine("");
            Console.WriteLine("==============");
            //Printing Student Results
            Console.WriteLine("Student Number : " + number);
            Console.WriteLine("Student Name : " + name);
            Console.WriteLine("Total Marks : " + totalMarks);
            Console.WriteLine("Average Marks : " + averageMarks);

            if (averageMarks <= 49)
            {
                Console.WriteLine("Grade is Fail");
            }
            else if (averageMarks <= 59)
            {
                Console.WriteLine("Grade is Pass");
            }
            else if (averageMarks <= 69)
            {
                Console.WriteLine("Grade is Credit");
            }
            else if (averageMarks <= 79)
            {
                Console.WriteLine("Grade is Very Good Pass");
            }
            else
            {
                Console.WriteLine("Grade is Distinction");
            }

            Console.ReadKey();
        }
    }
}
