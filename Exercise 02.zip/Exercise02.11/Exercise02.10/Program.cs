﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Radius of the Circle");
            int radius = Convert.ToInt32(Console.ReadLine());

            double circumference = (2 * 3.14 * radius );

            double area = (3.14 * (radius * radius));

            Console.WriteLine("Circumference of the circle : " + circumference);
            Console.WriteLine("Area of the circle : " + area);

            Console.ReadKey();
        }
    }
}
