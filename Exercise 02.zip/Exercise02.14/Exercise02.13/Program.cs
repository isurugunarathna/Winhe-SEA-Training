﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for(int i = 0; i < args.Length; i++)
            {

            }
            Console.WriteLine("Please Select the shape : ");
            Console.WriteLine("1. Circle");
            Console.WriteLine("2. Rectangle");
            Console.WriteLine("3. Cylinder");
            Console.WriteLine("0 - If you want to exit type zero");
            Console.WriteLine("---------");    
            Console.WriteLine("Enter the shape you want : ");
            int shapeNumber = Convert.ToInt32(Console.ReadLine());


            while (shapeNumber != 0)
            {
                if (shapeNumber == 1)
                {
                    Console.WriteLine("Entered Shape is : Circle");
                    Console.WriteLine("");

                    Console.WriteLine("Enter the Radius of the Circle");
                    int radius = Convert.ToInt32(Console.ReadLine());

                    double circumference = (2 * 3.14 * radius);

                    double area = (3.14 * (radius * radius));

                    Console.WriteLine("Circumference of the circle : " + circumference);
                    Console.WriteLine("Area of the circle : " + area);
                }
                else if (shapeNumber == 2)
                {
                    Console.WriteLine("Entered Shape is : Recatangle");
                    Console.WriteLine("");

                    Console.WriteLine("Enter the height of the Rectangle : ");
                    int height = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the width of the Rectangle :");
                    int width = Convert.ToInt32(Console.ReadLine());

                    int perimeter = (2 * (height + width));
                    int area = (height * width);

                    Console.WriteLine("Perimeter of the Rectangle : " + perimeter);
                    Console.WriteLine("Area of the Rectangle : " + area);

                }
                else if (shapeNumber == 3)
                {
                    Console.WriteLine("Entered Shape is : Cylinder");
                    Console.WriteLine("");

                    Console.WriteLine("Enter the Radius of the base :");
                    int radius = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the height of the cylinder :");
                    int height = Convert.ToInt32(Console.ReadLine());

                    double surfaceArea = ((2 * 3.14 * radius) * height);

                    double volume = (3.14 * (radius * radius) * height);

                    Console.WriteLine("Surface Area of the Cylinder : " + surfaceArea);
                    Console.WriteLine("Volume of the Cylinder : " + volume);

                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }
                Console.Write("Input the Number above list : ");
                shapeNumber = Convert.ToInt32(Console.ReadLine());

            }


            Console.WriteLine("Thank You");
            Console.ReadKey();
        }
    }
}
