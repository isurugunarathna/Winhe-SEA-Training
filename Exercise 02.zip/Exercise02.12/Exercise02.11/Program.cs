﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the height of the Rectangle : ");
            int height = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the width of the Rectangle :");
            int width = Convert.ToInt32(Console.ReadLine());

            int perimeter = (2 * (height + width) );
            int area = (height * width);

            Console.WriteLine("Perimeter of the Rectangle : " + perimeter );
            Console.WriteLine("Area of the Rectangle : " + area);

            Console.ReadKey();

        }
    }
}
