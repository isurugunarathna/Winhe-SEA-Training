﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02._03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Name");
            String name = Console.ReadLine();

            Console.WriteLine("Hello " + name);

            Console.ReadKey();
        }
    }
}
