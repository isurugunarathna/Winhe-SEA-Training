﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise07._02
{
    internal class Author
    {
        private string name;
        private string email;

        public Author(string name, string email )
        {
            this.name = name;
            this.email = email;
        }
        public string GetValueName()
        {
            return name;
        }
        public string GetValueEmail()
        {
            return email;
        }
        public void SetName()
        {
            this.name=name;
        }
        public void SetEmail()
        {
            this.email=email;
        }

        public void ToString()
        {
            Console.WriteLine("Author[name= " + name + " " +
                ", email= " + email + "]");
        }
    }
}
