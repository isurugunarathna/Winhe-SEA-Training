﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise07._02
{
    internal class Book
    {
        private String isbn;
        private String name;
        private Author author;
        private double price;
        private int qty = 0;

        public Book(string isbn, string name, Author author, double price, int qty)
        {
            this.isbn = isbn;
            this.name = name;
            this.author = author;
            this.price = price;
            this.qty = qty;
        }
        public String getISBN()
        {
            return isbn;
        }

        public String getName()
        {
            return name;
        }

        public Author GetAuthor()
        {
            return author;
        }

        public double getPrice()
        {
            return price;
        }

        public void setPrice(double price)
        {
            this.setPrice(price);
        }

        public int getQty()
        {
            return qty;
        }

        public void setQty(int qty)
        {
            this.setQty(qty);
        }
        public string GetAuthorName()
        {
            return author.GetValueName();
        }
        public string ToString()
        {
            string text = "Book[isbn= " + isbn + " " +
                ", name = " + name + "  " +
                ", Author[name = " + author.GetValueName() + "  " +
                ", email = " + author.GetValueEmail() + "] " +
                ", price = " + price + "  " +
                ", qty= " + qty + " ]";
            return text;
        }
    }
}
