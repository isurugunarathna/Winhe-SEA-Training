﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, r, sum, temp;
            int stno, enno;

            Console.Write("\n\n");
            Console.WriteLine("Find the Armstrong numbers from 1 - 500");
            Console.Write("--------------------------------------------------------");
            Console.Write("\n\n");

           

            Console.Write("Armstrong numbers in given range are: ");
            for (num = 1; num <= 500; num++)
            {
                temp = num;
                sum = 0;

                while (temp != 0)
                {
                    r = temp % 10;
                    temp = temp / 10;
                    sum = sum + (r * r * r);
                }
                if (sum == num)
                    Console.Write("{0} ", num);
            }
            Console.Write("\n");
            Console.ReadKey();
        }
    }
}
