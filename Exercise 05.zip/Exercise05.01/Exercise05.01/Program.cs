﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int  result,x;

            Console.WriteLine("Enter first Number :");
            int firstNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second Number : ");
            int secondNumber = Convert.ToInt32(Console.ReadLine());

            result = 1;
            x = secondNumber;

            while (secondNumber != 0)
            {
                result = result * firstNumber;
                secondNumber = secondNumber - 1;
            }
            Console.WriteLine("{0} raised to the power {1} : {2}", firstNumber, x, result);

            Console.ReadKey();
        }
    }
}
