﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variable declaration
            int randomNumber;
            int userInputNumber;
            int chances = 7;

            //genarate random number
            Random random = new Random();
            randomNumber = random.Next(0, 100);

            Console.WriteLine("        Simple Number Guessing Game");
            Console.WriteLine("");
            Console.WriteLine("        Please guess a number between 0-100 ");
            Console.WriteLine("");
            Console.WriteLine("        You Have only 7 chances");
            Console.WriteLine("");

            //user can try only seven time
            for (int i = 0; i < chances; i++)
            {
                //get user input number
                Console.WriteLine("Guess the number between 0 - 100 : ");
                userInputNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Your chance :" + i);

                //check guess number conditions
                if (userInputNumber == randomNumber)
                {
                    Console.WriteLine("Congratulations !!!\nYou are correct");
                    break;
                }
                else if (userInputNumber > randomNumber)
                {
                    Console.WriteLine("Too high, try again!");
                }
                else
                {
                    Console.WriteLine("Too low, try again!");
                }

            }
            Console.WriteLine("Game Over\nThe Number is : " + randomNumber);

            Console.ReadKey();


        }
    }
}
