﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._04
{
    internal class Program
    {
        public static string Reverse(string word)
        {
            char[] charArray = word.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        static void Main(string[] args)
        {

            String inputValue;
            String reverseValue;

            //get user inputs
            Console.WriteLine("Enter the word to check Palindrome or not : ");
            inputValue = Console.ReadLine();

            //calling reverse function
            reverseValue = Reverse(inputValue);

            //check the word is palindrome or not
            if (reverseValue == inputValue)
            {
                Console.WriteLine("The word is palindrome");
            }
            else
            {
                Console.WriteLine("The word is not palindrome");
            }


            Console.ReadKey();
        }
    }
}
