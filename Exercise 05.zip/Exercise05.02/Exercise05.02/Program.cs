﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("                Farenheit to Celcius Converter");
            Console.WriteLine("");

            Console.WriteLine("Enter Temperature in Farenheit :");
            double Fahrenheit = Convert.ToDouble(Console.ReadLine()); ;

            double Celsius = FahrenheitCelsius(Fahrenheit);
            Console.WriteLine("The converted Celsius temperature is:" + Celsius);
            Console.ReadLine();
        }
        private static double FahrenheitCelsius(double Fahrenheit)
        {
            return (Fahrenheit - 32) * 5 / 9;
        }
        
        }
    }
