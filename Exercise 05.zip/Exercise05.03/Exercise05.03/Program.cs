﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise05._03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            int[] inputNumber = new int[100];

            Console.WriteLine("Read n number of values in an array and display it in reverse order:");
            Console.WriteLine("------------------------------------------------------------------------");

            Console.Write("Input the number of elements to store in the array :");
            int numberofElements = Convert.ToInt32(Console.ReadLine());


            //elements in the array

            Console.WriteLine("Input {0} number of elements in the array : ", numberofElements);
            for (i = 0; i < numberofElements; i++)
            {
                Console.Write("element - {0} : ", i);
                inputNumber[i] = Convert.ToInt32(Console.ReadLine());
            }

            //into array

            Console.Write("\nThe values store into the array are : \n");
            for (i = 0; i < numberofElements; i++)
            {
                Console.Write("{0}  ", inputNumber[i]);
            }

            //array reverse

            Console.Write("\n\nThe values store into the array in reverse are :\n");
            for (i = numberofElements - 1; i >= 0; i--)
            {
                Console.Write("{0} ", inputNumber[i]);
            }
            Console.Write("\n\n");

            Console.ReadKey();
        }
    }
}
