﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise07
{
    internal class Point3D : Point
    {
        //part I
        private int z;

        //part J
        public Point3D() : base()
        {
            z = 300;
        }
        //part K
        public Point3D(int z,int x,int y) : base(x,y)
        {
            this.z = z;
        }
        //part L -- overide
        public void SetValuesZ()
        {
            SetValueX(1000);
            SetValueY(2000);
            z = 3000;
        }
        public int GetValueZ()
        {
            return z;
        }
        public override void SetParameters()
        {
            base.SetParameters();
            z = 3000;
         
        }

        public override void SetParameters(int x, int y)
        {
            base.SetParameters(x, y);
            this.z = z;
        }


    }
}
