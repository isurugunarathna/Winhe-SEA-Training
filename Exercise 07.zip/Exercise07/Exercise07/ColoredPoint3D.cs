﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise07
{
    internal class ColoredPoint3D : Point3D
    {
        private string color;
        private string green;

        public ColoredPoint3D() : base()
        {
            color = green;
            
        }

    }
}
