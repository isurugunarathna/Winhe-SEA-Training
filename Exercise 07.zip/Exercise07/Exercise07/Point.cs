﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise07
{
    internal class Point
    {
        protected int x;
        protected int y;
        public void SetValueX(int x)
        {
            this.x = x;
        }

        public void SetValueY(int y)
        {
            this.y = y;
        }

        //getters
        public int GetValueX()
        {
            return x;
        }

        public int GetValueY()
        {
            return y;
        }

        public Point()
        {
            x = 100;
            y = 200;
        }
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        //part g
        public virtual void SetParameters()
        {
            x = 1000;
            y = 2000;

        }

        //part h
        public virtual void SetParameters(int x,int y)
        {
            this.x=x;
            this.y=y;
        }

    }
}
